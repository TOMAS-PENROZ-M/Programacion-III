from fastapi import FastAPI, Depends
from sqlalchemy.orm import Session
from database import SessionLocal, engine
from models import Base, Mision, Personaje
import schemas
from nose import ArrayQueue

Base.metadata.create_all(bind=engine)
app = FastAPI()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@app.post("/personajes", response_model=schemas.PersonajeOut)
def crear_personaje(p: schemas.PersonajeCreate, db: Session = Depends(get_db)):
    personaje = Personaje(nombre=p.nombre)
    db.add(personaje)
    db.commit()
    db.refresh(personaje)
    return personaje

@app.post("/misiones", response_model=schemas.MisionOut)
def crear_mision(m: schemas.MisionCreate, db: Session = Depends(get_db)):
    mision = Mision(**m.model_dump())
    db.add(mision)
    db.commit()
    db.refresh(mision)
    return mision

@app.post("/personajes/{personaje_id}/encolar")
def encolar_mision(personaje_id: int, entrada: schemas.EncolarMisionInput, db: Session = Depends(get_db)):
    return ArrayQueue.EncolarMision(db, personaje_id, entrada.mision_id, entrada.prioridad)

@app.delete("/personajes/{personaje_id}/desencolar")
def desencolar_mision(personaje_id: int, db: Session = Depends(get_db)):
    return ArrayQueue.DesencolarMision(db, personaje_id)

@app.get("/personajes/{personaje_id}/primera")
def ver_primera_mision(personaje_id: int, db: Session = Depends(get_db)):
    return ArrayQueue.VerPrimeraMision(db, personaje_id)

@app.get("/personajes/{personaje_id}/ver_misiones")
def ver_misiones(personaje_id: int, db: Session = Depends(get_db)):
    return ArrayQueue.VerMisiones(db, personaje_id)

@app.get("/personajes/{personaje_id}/cantidad")
def vacia(personaje_id: int, db: Session = Depends(get_db)):
    return ArrayQueue.Vacia(db, personaje_id)