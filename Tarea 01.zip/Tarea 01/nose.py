from models import Personaje, Mision, MisionPersonaje
from sqlalchemy.orm import Session

#def Encolarpersonaje(db: Session, nombre: str):#####return nuevo
class ArrayQueue():
    def __init__(self):
        self.items = []

    def EncolarMision(db: Session, personaje_id: int, misiones_id: int, prioridad: int = 1):
        count = db.query(MisionPersonaje).filter(MisionPersonaje.personaje_id == personaje_id).count()
        nuevo = MisionPersonaje(personaje_id=personaje_id, misiones_id=misiones_id,orden=count + 1, prioridad=prioridad)
        db.add(nuevo)
        db.commit()
        db.refresh(nuevo)
        return nuevo

    def DesencolarMision(db: Session, personaje_id: int):
        primero = db.query(MisionPersonaje).filter(MisionPersonaje.personaje_id == personaje_id)\
            .order_by(MisionPersonaje.prioridad.desc(), MisionPersonaje.orden).first()
        if primero:
            db.delete(primero)
            db.commit()
            return primero
        return None

    def VerPrimeraMision(db: Session, personaje_id:int):
        ver = db.query(MisionPersonaje).filter(MisionPersonaje.personaje_id == personaje_id)\
            .order_by(MisionPersonaje.prioridad.desc(), MisionPersonaje.orden).first()
        if ver is None:
            raise ValueError("No hay misiones disponibles")
        return ver

    def VerMisiones(db: Session, personaje_id: int):
        return db.query(MisionPersonaje).filter(MisionPersonaje.personaje_id == personaje_id).count()

    def Vacia(db: Session, personaje_id: int):
        return db.query(MisionPersonaje).filter(MisionPersonaje.personaje_id == personaje_id).first() is not None


