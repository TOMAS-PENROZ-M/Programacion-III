from pydantic import BaseModel
from datetime import datetime
from enum import Enum as PyEnum

class EstadoEnum(str, PyEnum):
    Pendiente = 'Pendiente'
    completada = 'Completada'

class MisionBase(BaseModel):
    nombre: str
    descripcion: str
    experiencia: int
    estado: EstadoEnum
    fecha: datetime

class MisionCreate(MisionBase):
    pass 

class MisionOut(MisionBase):
    id: int

    model_config = {
        "from_attributes": True
    }

class PersonajeCreate(BaseModel):
    nombre: str

class PersonajeOut(PersonajeCreate):
    id: int

    model_config = {
        "from_attributes": True
    }

class EncolarMisionInput(BaseModel):
    mision_id: int
    prioridad: int = 1