from sqlalchemy import Column, Integer, String, Enum, DateTime, ForeignKey
from datetime import datetime
from sqlalchemy.orm import relationship
from database import Base

class Mision(Base):
    __tablename__= 'misiones'

    id = Column(Integer, primary_key=True)
    nombre = Column(String(50), nullable=False)
    descripcion = Column(String(100), nullable=False)
    experiencia = Column(Integer, default=0)
    estado = Column(Enum('Pendiente', 'Completada', name ='Estados'), nullable=False)
    fecha = Column(DateTime, default=datetime.now)

    personajes = relationship("MisionPersonaje", back_populates="mision")

class Personaje(Base):
    __tablename__= 'personajes'

    id = Column(Integer, primary_key=True)
    nombre = Column(String(30), nullable=False)

    misiones = relationship("MisionPersonaje", back_populates="personaje")

class MisionPersonaje(Base):
    __tablename__= 'misiones_personaje'

    personaje_id = Column(Integer, ForeignKey('personajes.id'), primary_key=True)
    misiones_id = Column(Integer, ForeignKey('misiones.id'), primary_key=True)
    orden = Column(Integer)
    prioridad = Column(Integer, default=1)

    personaje = relationship("Personaje", back_populates="misiones")
    mision = relationship("Mision", back_populates="personajes")

    