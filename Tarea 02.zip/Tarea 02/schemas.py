from pydantic import BaseModel
from datetime import datetime
from typing import Optional, Literal


class VueloBase(BaseModel):
    codigo : str
    estado : Literal["Programado", "Emergencia", "Retrasado"]
    hora : datetime
    origen : str
    destino : str

class VueloCreate(VueloBase):
    pass 

class VueloOut(VueloBase):
    hora: datetime

    class Config:
        from_attributes: True

class VueloUpadate(VueloBase):
    codigo: str

    class Config:
        from_attributes: True
