from sqlalchemy import Column, String, Enum, DateTime
from datetime import datetime
from database import Base

class Vuelo(Base):
    __tablename__ = "Vuelos"

    codigo = Column(String, primary_key=True )
    estado = Column(Enum('Programado', 'Emergencia', 'Retrasado', name = 'Estados'), nullable=False)
    hora = Column(DateTime, default=datetime.now)
    origen = Column(String(50), nullable=False)
    destino = Column(String(50), nullable=False)