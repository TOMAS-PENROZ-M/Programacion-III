from fastapi import FastAPI, HTTPException, Body
from models import Base, Vuelo
import schemas
from database import engine
from listadoble import ListaVuelos
from typing import List

Base.metadata.create_all(bind=engine)

app = FastAPI()
lista = ListaVuelos()


@app.post("/vuelo/", response_model=schemas.VueloOut)
def agregar_vuelo(vuelo_add: schemas.VueloCreate):
    vuelo = Vuelo(**vuelo_add.model_dump())
    lista.agregar_vuelo(vuelo)
    return vuelo

@app.get("/vuelo/primero", response_model=schemas.VueloOut)
def obtener_primero():
    vuelo = lista.obtener_primero()
    if vuelo:
        return vuelo
    raise HTTPException(status_code=404, detail="No hay vuelos")

@app.get("/vuelo/ultimo", response_model=schemas.VueloOut)
def obtener_ultimo():
    vuelo = lista.obtener_ultimo()
    if vuelo:
        return vuelo
    raise HTTPException(status_code=404, detail="No hay vuelos")

@app.get("/vuelo/longitud")
def obtener_longitud():
    return {"Total de vuelos": lista.longitud()}

@app.get("/vuelo/lista", response_model=List[schemas.VueloOut])
def obtener_lista():
    return lista.obtener_lista()

@app.post("/vuelo/insertar/{posicion}", response_model=schemas.VueloOut)
def insertar_vuelo(vuelo_ins: schemas.VueloCreate, posicion: int):
    vuelo = Vuelo(**vuelo_ins.model_dump())
    lista.insertar_posicion(vuelo, posicion)
    return vuelo

@app.get("/vuelo/extraer/{posicion}", response_model=schemas.VueloOut)
def extraer_vuelo(posicion: int):
    vuelo = lista.extraer_posicion(posicion)
    if vuelo:
        return vuelo
    raise HTTPException(status_code=404, detail="Posicion Invalida")

@app.patch("/vuelo/{vuelo_id}", response_model=schemas.VueloUpadate)
def actualizar_estado_vuelo(vuelo_codigo: str, nuevo_estado: str = Body(...)):
    vuelo = lista.db.query(Vuelo).filter(Vuelo.codigo == vuelo_codigo).first()
    if not vuelo:
        raise HTTPException(status_code=404, detail="Vuelo no encontrado")

    vuelo.estado = nuevo_estado
    lista.db.commit()
    lista.db.refresh(vuelo)

    if nuevo_estado == "Emergencia":
        lista.mover_a_inicio_si_emergencia(vuelo_codigo)

    return vuelo