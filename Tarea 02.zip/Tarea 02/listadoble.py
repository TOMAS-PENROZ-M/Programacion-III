from database import SessionLocal
from models import Vuelo


class Nodo():
    def __init__(self, vuelo):
        self.vuelo = vuelo
        self.anterior = None
        self.siguiente = None

class ListaVuelos():

    def __init__(self):
        self.head = None
        self.tail = None
        self.size = 0
        self.db = SessionLocal()

    def is_empty(self):
        return self.size == 0
    
    def insertar_inicio(self, vuelo: Vuelo):
        self.db.add(vuelo)
        self.db.commit()
        self.db.refresh(vuelo)

        nuevo = Nodo(vuelo)
        if self.is_empty():
            self.head = nuevo
            self.tail = nuevo
        else:
            nuevo.siguiente = self.head
            self.head.anterior = nuevo
            self.head = nuevo
        self.size += 1
    
    def insertar_final(self, vuelo: Vuelo):
        self.db.add(vuelo)
        self.db.commit()
        self.db.refresh(vuelo)

        nuevo = Nodo(vuelo)
        if self.is_empty():
            self.head = nuevo
            self.tail = nuevo
        else:
            self.tail.siguiente = nuevo
            nuevo.anterior = self.tail
            self.tail = nuevo
        self.size += 1

    def agregar_vuelo(self, vuelo: Vuelo):
        if vuelo.estado == 'Emergencia':
            self.insertar_inicio(vuelo)
        else:
            self.insertar_final(vuelo)

    def obtener_primero(self):
        if self.is_empty():
            return None
        return self.head.vuelo
    
    def obtener_ultimo(self):
        if self.is_empty():
            return None
        return self.tail.vuelo
    
    def longitud(self):
        return self.size
    
    def obtener_lista(self):
        vuelos = []
        actual = self.head
        while actual:
            vuelos.append(actual.vuelo)
            actual = actual.siguiente
        return vuelos
    
    def insertar_posicion(self, vuelo: Vuelo, posicion: int):
        self.db.add(vuelo)
        self.db.commit()
        self.db.refresh(vuelo)

        if posicion <= 0:
            self.insertar_inicio(vuelo)
        elif posicion >= self.size:
            self.insertar_final(vuelo)
        else:
            nuevo = Nodo(vuelo)
            actual = self.head
            for _ in range(posicion):
                actual = actual.siguiente
            anterior = actual.anterior
            anterior.siguiente = nuevo
            nuevo.anterior = anterior
            nuevo.siguiente = actual
            actual.anterior = nuevo
        self.size += 1

    def extraer_posicion(self, posicion: int):
        if posicion < 0 or posicion >= self.size:
            return None

        actual = self.head
        for _ in range(posicion):
            actual = actual.siguiente

        vuelo = actual.vuelo

        if actual.anterior:
            actual.anterior.siguiente = actual.siguiente
        else:
            self.head = actual.siguiente

        if actual.siguiente:
            actual.siguiente.anterior = actual.anterior
        else:
            self.tail = actual.anterior

        self.db.delete(vuelo)
        self.db.commit()

        self.size -= 1
        return vuelo
    
    def mover_a_inicio_si_emergencia(self, vuelo_codigo: str):
        actual = self.head
        while actual:
            if actual.vuelo.codigo == vuelo_codigo:
                if actual.vuelo.estado != "Emergencia":
                    return  

                
                if actual.anterior:
                    actual.anterior.siguiente = actual.siguiente
                else:
                    self.head = actual.siguiente

                if actual.siguiente:
                    actual.siguiente.anterior = actual.anterior
                else:
                    self.tail = actual.anterior

                
                actual.siguiente = self.head
                if self.head:
                    self.head.anterior = actual
                self.head = actual
                actual.anterior = None
                return
            actual = actual.siguiente